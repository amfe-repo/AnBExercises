//Autor: AnibalNivar 
//ID.  : 1100334

/*Hacer un programa que, reciba 3 números desde el teclado (Puede llamarles A, B, C, o como entienda).  #OJO#
Esos tres valores serán considerados los coeficientes de
 AX2 + BX + C = 0.  


El programa deberá generar una salida como Sigue:

  •	Si estos 3 valores realmente conforman una ecuación cuadrática
  •	Cuáles son los valores de X1 / X2 que realmente satisfacen la ecuación con dichos coeficientes
  •	Determinar excepciones de tipo de resultado que puedan tenerse (ie – imaginarios?)
*/

#include <stdio.h>
#include <math.h>

int main(){

  int n1 = 0, n2 = 0, n3 = 0;
  float res_x1 = 0.0, res_x2 = 0.0;

  printf("Dame 3 numeros: ");
  scanf("%i %i %i", &n1, &n2, &n3);


  res_x1 = ((n2*-1) + sqrt( pow(n2,2) - (4 * n1 * n3) ))/(2 * n1);
  
  res_x2 = ((n2*-1) - sqrt( pow(n2,2) - (4 * n1 * n3) ))/(2 * n1);
  
  if(isnan(res_x1)) {

    printf("La ecuacion se queda indeterminda, solo puede solucionarse con numeros imaginarios");

  }else{

    printf("X1: %f \n", res_x1);
    printf("X2: %f", res_x2);

  }

  
  return 0;
}