//Autor: AnibalNivar 
//ID.  : 1100334

/* Que pida una letra y detecte si es una vocal. (Hacerlo usando IF … punto adicional si usa estructura switch / case) */

#include <stdio.h>

int main(){

  char letter = 'a';

  printf("Dame una vocal: ");
  scanf("%c", &letter);

  //Verifica si la letra ingresada es una vocal o no
  switch(letter){

    case 'a':
    case 'e':
    case 'i':
    case 'o':
    case 'u':
      printf("Es una vocal");
      break;
    default:
      printf("No es una vocal");

  }

  return 0;
}