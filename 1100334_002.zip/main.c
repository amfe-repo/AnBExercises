//Autor: AnibalNivar 
//ID.  : 1100334

/* Que pida un número del 1 al 7 y diga el día de la semana correspondiente. (solo hacerlo usando estructuras IF)  */

#include <stdio.h>


int main(){

  int n1 = 0;


  printf("Dame el numero de la semana: \n");
  scanf("%i", &n1);
  
  if(n1 == 1){
    printf("Hoy es lunes");
  }
  if(n1 == 2){
    printf("Hoy es martes");
  }
  if(n1 == 3){
    printf("Hoy es miercoles");
  }
  if(n1 == 4){
    printf("Hoy es jueves");
  }
  if(n1 == 5){
    printf("Hoy es viernes");
  }
  if(n1 == 6){
    printf("Hoy es sabado");
  }
  if(n1 == 7){
    printf("Hoy es domingo");
  }
  

  return 0;
}