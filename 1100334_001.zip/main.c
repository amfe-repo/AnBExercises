//Autor: AnibalNivar 
//ID.  : 1100334

/* Ejercicio: Que tome dos números del 1 al 5 y diga si ambos son primos. */

#include <stdio.h>


int main(){
  //Crear 2 variables de tipo entero, llaman: n1 y n2

  int n1 = 0;
  int n2 = 0;

  printf("Escriba numeros entre 1 y 5\n");

  printf("Dame el primer numero: ");
  scanf("%i", &n1);
  
  printf("Dame el segundo numero: ");
  scanf("%i", &n2);

  // 1, 2, 3, 4, 5
  if(n1 >= 1 && n1 <= 5){

    if(n1 == 2 || n1 == 3 || n1 == 5){  
    printf("%i es primo \n ",n1);
    }
    else{
      printf("%i no es primo \n ",n1);
    }

  }
  else{

    printf("%i no esta entre 1 y 5 \n ",n1);

  }
  
  if(n2 >= 1 && n2 <= 5){

    if(n2 == 2 || n2 == 3 || n2 == 5){  
      printf("%i es primo \n ", n2);
    }
    else{
      printf("%i no es primo \n ",n2);
    }

  }
  else{

    printf("%i no esta entre 1 y 5 \n ",n2);

  }
  

  

  return 0;
}