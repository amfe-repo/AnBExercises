//Autor: AnibalNivar 
//ID.  : 1100334

/* Que pida un número y diga si es par o impar, y a la vez si es positivo o negativo. */

#include <stdio.h>


int main(){

  int n1 = 0;

  printf("Dame un numero: ");
  scanf("%i", &n1);
  
  //Comprueba si el numero par o impar
  if(n1 % 2 == 0){
    printf("El numero es par\n");
  }
  else{
    printf("El numero es impar\n");
  }

  //Comprueba si el numero positivo o negativo
  if(n1 < 0){
    printf("El numero es negativo");
  }else{
    printf("El numero es positivo");
  }

  return 0;
}