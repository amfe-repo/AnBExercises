//Autor: AnibalNivar 
//ID.  : 1100334

/* Que capture 3 números, y los muestre en pantalla:

  •	De menor a mayor.
  •	Mayor a menor.
  •	Que al mostrarlos en pantalla, si son distintos use líneas distintas, en caso de ser iguales mostrarlos en la misma línea

*/

#include <stdio.h>

int main(){

  int arr[3];
  int max = 0, min = 999, mild = 0, sum = 0;
  
  printf("Dame los numeros: ");
  scanf("%i %i %i", &arr[0], &arr[1], &arr[2]);
  
  for(int counter = 0; counter < 3; counter++){
    
    sum = sum + arr[counter];

    if(arr[counter] > max){

      max = arr[counter];

    }

    if(arr[counter] < min){

      min = arr[counter];

    }

  }
  
  mild = sum - max;
  mild = mild - min;

  if(max == min && max == mild){

    printf("MIN: %i MILD: %i MAX: %i\n", min, mild, max);
    printf("MAX: %i MILD: %i MIN: %i", max, mild, min);

  }
  else{

    if(max != min && min != mild){

      printf("\nMenor a mayor:\n");
      printf("MIN: %i\nMILD: %i\nMAX: %i\n", min, mild, max);

      printf("\nMayor a menor:\n");
      printf("MAX: %i\nMILD: %i\nMIN: %i", max, mild, min);

    }
    
  }
  

  return 0;
}