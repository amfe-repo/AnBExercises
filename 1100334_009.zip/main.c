//Autor: AnibalNivar 
//ID.  : 1100334

/* Hacer un programa que, reciba 3 números desde el teclado (Puede llamarles A, B, C, o como entienda).
Restricciones:
El programa debe asegurar que estos 3 números sean Enteros Positivos
Una vez validado esto, El programa deberá generar una salida como Sigue:
  •	Si algún valor fuese negativo, presentar “Valores negativos introducidos” 
  •	Si A>=B  y  A>=C; Presentar el mensaje “Combinación #1”
  •	Si B>=A  y  B>=C; Presentar el mensaje “Combinación #2”
  •	Si C>=A  y  C>=B; Presentar el mensaje “Combinación #3 */

#include <stdio.h>

int main(){

  int n1 = 0, n2 = 0, n3 = 0;

  scanf("%i %i %i", &n1, &n2, &n3);

  if(n1 >= 0 && n2 >= 0 && n3 >= 0) {

    if(n1 >= n2 && n1 >= n3) {

      printf("Combinacion #1");

    }

    if(n2 >= n1 && n2 >= n3) {

      printf("Combinacion #2");
      
    }

    if(n3 >= n2 && n3 >= n1) {

      printf("Combinacion #3");
      
    }

  }else{

    printf("Valores negativos introducidos");

  }


  return 0;
}