//Autor: AnibalNivar 
//ID.  : 1100334

/* Que pida un número del 1 al 12 y diga el nombre del mes correspondiente. (solo hacerlo usando estructuras IF)  */

#include <stdio.h>


int main(){

  int n1 = 0;


  printf("Dame el numero del mes: \n");
  scanf("%i", &n1);
  
  if(n1 == 1){
    printf("Es Enero");
  }
  if(n1 == 2){
    printf("Es Febrero");
  }
  if(n1 == 3){
    printf("Es Marzo");
  }
  if(n1 == 4){
    printf("Es Abril");
  }
  if(n1 == 5){
    printf("Es Mayo");
  }
  if(n1 == 6){
    printf("Es Junio");
  }
  if(n1 == 7){
    printf("Es Julio");
  }
  if(n1 == 8){
    printf("Es Agosto");
  }
  if(n1 == 9){
    printf("Es Septiembre");
  }
  if(n1 == 10){
    printf("Es Octubre");
  }
  if(n1 == 11){
    printf("Es Noviembre");
  }
  if(n1 == 12){
    printf("Es Diciembre");
  }
  

  return 0;
}