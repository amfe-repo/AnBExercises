//Autor: AnibalNivar 
//ID.  : 1100334

/* Hacer un programa que, reciba 3 números desde el teclado (Puede llamarles A, B, C, o como entienda).  
Esos tres valores potencialmente formaran un triángulo. */

#include <stdio.h>
#include <math.h>

int main(){

  //Declaramos las variables
  int A = 0, B = 0, C = 0, perimeter = 0, area = 0;
  float angle_A = 0, angle_B = 0, angle_C = 0;

  printf("Dame 3 numeros: ");
  scanf("%i %i %i", &A, &B, &C);

  if(A <= 0 || B <= 0 || C <= 0) {

    printf("Error: Uno de los digitos es negativo o igual a cero\n");

  }
  else{
    
    if((A + B) > C && (B + C) > A && (A + C) > B){
      
      //Calcular el area del triangulo
      perimeter = (A+B+C)/2;
      area = perimeter * ((perimeter - A) * (perimeter - B) * (perimeter - C));
      area = sqrt(area);

      //Calcular los angulos del triangulo
      angle_A = acos( (pow(B,2) + pow(C,2) - pow(A,2))/ (2*B*C) );
      angle_B = acos( (pow(A,2) + pow(C,2) - pow(B,2))/ (2*A*C) );
      
      angle_C = acos( (pow(C,2) - pow(A,2) - pow(B,2))/ (2*A*C) );
      
      //Clasificacion angular
      printf("\nClasificacion angular: \n");
      if(angle_A == 90 || angle_B == 90 || angle_C == 90){
        printf("Triangulo rectangulo\n");
      }
      else{

        if( (angle_A > 90 && angle_A < 180) || (angle_B > 90 && angle_B < 180) ||(angle_C > 90 && angle_C < 180)){

          printf("Triangulo obtusangulo\n");
          
        }

        if(angle_A < 90 && angle_B < 90 && angle_C < 90){

          printf("Triangulo acutangulo\n");
          
        }

      }

      //Clasificacion lateral
      printf("\nClasificacion lateral: \n");
      if(A == B && B == C && A == C){

        printf("Triangulo equilatero\n");

      }
      else{

        if(A != B && B != C && A != C){
          printf("Triangulo escaleno\n");
        }else{
          printf("Triangulo isosceles\n");
        }

      }

      printf("\nLos lados son a:%i b:%i c:%i", A, B, C);
      printf("\nLos angulos son A:%f B:%f C:%f", (180/3.1416) * angle_A, (180/3.1416) * angle_B, (180/3.1416) * angle_C);


    }
    else{

      printf("Valores no conforman un triangulo");

    }

  }


  return 0;
}