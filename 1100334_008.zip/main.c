//Autor: AnibalNivar 
//ID.  : 1100334

/* Que capture dos números y detecte:

  a.	Si se han introducido en orden creciente o decreciente.
  b.	Si ambos son pares o impares.

*/

#include <stdio.h>

int main(){

  int n1 = 0, n2 = 0;

  printf("Dame dos numeros: ");
  scanf("%i %i", &n1, &n2);

  //Verificar si el orden es decreciente o creciente
  if(n1 > n2){
    printf("El orden es decreciente\n");
  }
  else{
    printf("El orden es creciente\n");
  }

  //Verficar si es impar o par
  if(n1 % 2 == 0){
    printf("El numero %i es par\n", n1);
  }
  else{
    printf("El numero %i es impar\n", n1);
  }

  if(n2 % 2 == 0){
    printf("El numero %i es par\n", n2);
  }
  else{
    printf("El numero %i es impar\n", n2);
  }

  return 0;
}