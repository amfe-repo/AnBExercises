//Autor: AnibalNivar 
//ID.  : 1100334

/* Que sólo permita introducir los caracteres S y N (Mayúscula o Minúscula) */

#include <stdio.h>

int main(){

  char n1 = 'S';

  printf("Dame un caracter: ");
  scanf("%c", &n1);

  //Verifica si n1 esta entre las posibilidades del ejercicio
  if(n1 == 'S' || n1 == 's' || n1 == 'N' || n1 == 'n'){
    printf("El caracter es %c \n", n1);
  }
  else{
    printf("Caracter equivocado \n");
  }
  
  return 0;
}