//Autor: AnibalNivar 
//ID.  : 1100334

/*Que capture tres números e indicar:

    A.Si el tercero es igual a la suma del primero y el segundo.

    B.Si la multiplicación de los dos primeros es igual al tercero.

    C.Si el tercero es el resto de la división de los dos primeros. */

#include <stdio.h>

int main(){

  int n1 = 0, n2 = 0, n3 = 0;

  printf("Dame 3 numeros: ");
  scanf("%i %i %i", &n1, &n2, &n3);

  if(n3 == n1 + n2){
    printf("El tercero es igual a la suma del primero y el segundo.");
  }

  if(n3 == n1 * n2){
    printf("La multiplicación de los dos primeros es igual al tercero.");
  }

  if(n3 == n1 % n2){
    printf("El tercero es el resto de la división de los dos primeros.");
  }

  
  return 0;
}