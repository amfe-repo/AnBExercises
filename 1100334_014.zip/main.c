//Autor: AnibalNivar 
//ID.  : 1100334

/* Que lea una hora en HH:MM:SS y diga la hora que es un segundo después. */

#include <stdio.h>

int main(){

  int hora = 0, minutos = 0, segundos = 0;


  printf("Dame la hora: formato => (HH:MM:SS): ");
  scanf("%i %i %i", &hora, &minutos, &segundos);

  if(segundos == 59){

    if(minutos == 59){

      printf("\nLa hora en el futuro es: %i %i0 %i0", hora+1, minutos*0, segundos*0);
      
    }
    else{
      printf("\nLa hora en el futuro es: %i %i %i0", hora, minutos+1, segundos*0);
    }

  }
  else{
    printf("\nLa hora en el futuro es: %i %i %i", hora, minutos, segundos+1);
  }
  
  
  return 0;
}