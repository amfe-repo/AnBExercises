//Autor: AnibalNivar 
//ID.  : 1100334

/* Que capture un número y haga la conversión de Grados Fahrenheit a grados centígrados */

#include <stdio.h>

int main(){

  float fahrenheit = 0.0; 
  float resultado = 0.0;

  printf("Dame los datos en grados fahrenheit: ");
  scanf("%f", &fahrenheit);

  //Formula para convertir los grados a celsius
  resultado = (fahrenheit - 32) * 0.555; 

  printf("%f °F es igual a %f °C", fahrenheit, resultado);

  return 0;
}